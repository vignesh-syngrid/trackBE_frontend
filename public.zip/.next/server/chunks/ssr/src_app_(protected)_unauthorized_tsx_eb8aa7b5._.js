module.exports = {

"[project]/src/app/(protected)/unauthorized.tsx [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=src_app_%28protected%29_unauthorized_tsx_eb8aa7b5._.js.map