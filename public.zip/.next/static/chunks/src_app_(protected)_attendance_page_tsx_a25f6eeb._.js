(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a10e7732._.js",
  "static/chunks/src_e9fdb2d0._.js"
],
    source: "dynamic"
});
