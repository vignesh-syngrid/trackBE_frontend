(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__428a9a8a._.css",
  "static/chunks/node_modules_dfec5a37._.js",
  "static/chunks/src_371eb091._.js"
],
    source: "dynamic"
});
